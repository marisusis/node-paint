A Pen created at CodePen.io. You can find this one at http://codepen.io/spacegeek224/pen/LNdJpV.

 