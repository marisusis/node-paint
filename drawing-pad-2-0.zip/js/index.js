var canvas = document.getElementById('cdraw');
var ctx = canvas.getContext('2d');

var fg = document.getElementById('cfg');
var fgctx = fg.getContext('2d');




var App = {};

App.colors = ['red','orange','yellow','green','aqua','blue','purple','pink','brown','white'];

App.brush = { 
  sizes: {
    sm: 5,
    md: 10,
    lg: 20
  }
};

App.lineWidth = 5;
App.color = '#000';
//TOOLBOX CONTROLS

$('.shade').on('click touch',function(e) {
  $('.current').css('background',$(e.target).css('background-color'));
  App.color = $(e.target).css('background-color');
});

$('.hue').on('click touch',function(e) {
  $('.hue').removeClass('selected');
  $(e.target).addClass('selected');
  $('.shade').attr('data-color',$(e.target).attr('data-color'));
});

$('.size').on('click touch',function(e) {
  $('.size').removeClass('selected');
  $(e.target).addClass('selected');
  App.lineWidth = App.brush.sizes[$(e.target).attr('data-size')]
});

//CANVAS EVENTS

canvas.width = canvas.clientWidth;
canvas.height = canvas.clientHeight;
fg.width = canvas.clientWidth;
fg.height = canvas.clientHeight;

$('.editor').on('mousedown touchstart', function(e) {
  App.drawing = true;
  ctx.beginPath();
  if (e.type == 'touchstart') {
    var touch = e.originalEvent.changedTouches[0];
    ctx.moveTo(touch.pageX,touch.pageY);
  } else {
    ctx.moveTo(e.clientX,e.clientY);
  }
});

$('.editor').on('mousemove touchmove', function(e) {
  fgctx.fillStyle = App.color;
  fgctx.clearRect(0,0,fg.width,fg.height);

  if (e.type == 'touchmove') {
    var touch = e.originalEvent.changedTouches[0];
    fgctx.fillRect(touch.pageX-4.5,touch.pageY-4.5,10,10);
  } else {
    fgctx.fillRect(e.clientX-4.5,e.clientY-4.5,10,10);
  }
  // ctx.shadowColor = App.color;
  // ctx.shadowBlur = 5;
  ctx.strokeStyle = App.color;
  ctx.lineWidth = App.lineWidth;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";

  if (App.drawing) {
    if (e.type == 'touchmove') {
      var touch = e.originalEvent.changedTouches[0];
      ctx.lineTo(touch.pageX,touch.pageY);
      ctx.stroke();
    } else {
      ctx.lineTo(e.clientX,e.clientY);
      ctx.stroke();
    }
  }
});

$('.editor').on('mouseup touchend', function(e) {
  App.drawing = false;
  if (e.type == 'touchend') {
    var touch = e.originalEvent.changedTouches[0];
    ctx.lineTo(touch.pageX,touch.pageY);
    ctx.stroke();
  } else {
    ctx.lineTo(e.clientX,e.clientY);
    ctx.stroke();
  }

});

//WINDOW EVENTS

window.onresize = function(e) {
  console.log(e);
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  fg.width = window.innerWidth;
  fg.height = window.innerHeight;
};